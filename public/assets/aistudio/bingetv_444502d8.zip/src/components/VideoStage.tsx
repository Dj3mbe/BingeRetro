import { useEffect, useRef, useState } from "react";
import Hls from "hls.js";
import { ExternalLink, Play, Radio, Tv } from "lucide-react";
import type {
  Channel,
  ChannelSchedule,
  ClipPlanItem,
  NowNextInfo,
} from "../types/tv.ts";
import {
  buildPodPlan,
  formatClock,
  formatDuration,
  getNowNext,
  slotAt,
} from "../utils/scheduleEngine.ts";
import { WeatherStarView } from "./WeatherStarView.tsx";

interface VideoStageProps {
  channel: Channel | null;
  schedules: Record<string, ChannelSchedule>;
  globalAnchor: number;
  clips: ClipPlanItem[];
  plutoUrls: Record<string, string>;
  aspect43: boolean;
  scanlines: boolean;
  volume: number;
  muted: boolean;
  isPlaying: boolean;
  onPlayingChange: (playing: boolean) => void;
  showBannerSignal: number;
  digitBuffer: string;
  nowMs: number;
  videoRef: React.RefObject<HTMLVideoElement | null>;
  stageContainerRef: React.RefObject<HTMLDivElement | null>;
  onStageClick: () => void;
  couchMode?: boolean;
}

export function VideoStage({
  channel,
  schedules,
  globalAnchor,
  clips,
  plutoUrls,
  aspect43,
  scanlines,
  volume,
  muted,
  onPlayingChange,
  showBannerSignal,
  digitBuffer,
  nowMs,
  videoRef,
  stageContainerRef,
  onStageClick,
  couchMode = false,
}: VideoStageProps) {
  const [isLoading, setIsLoading] = useState(true);
  const [statusMessage, setStatusMessage] = useState<string>("");
  const [needsGesture, setNeedsGesture] = useState(false);
  const [bannerVisible, setBannerVisible] = useState(false);

  const tuneGenRef = useRef(0);
  const badUrlsRef = useRef<Set<string>>(new Set());
  const podTimerRef = useRef<number | null>(null);
  const retryTimerRef = useRef<number | null>(null);
  const bannerTimerRef = useRef<number | null>(null);
  const hlsRef = useRef<Hls | null>(null);

  // Sync volume & mute to video element
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;
    video.volume = Math.min(1, Math.max(0, volume));
    video.muted = muted;
  }, [volume, muted, videoRef]);

  // Show OSD banner briefly on channel tune or info trigger
  useEffect(() => {
    if (!channel) return;
    setBannerVisible(true);
    if (bannerTimerRef.current) window.clearTimeout(bannerTimerRef.current);
    bannerTimerRef.current = window.setTimeout(() => {
      setBannerVisible(false);
    }, 4500);
    return () => {
      if (bannerTimerRef.current) window.clearTimeout(bannerTimerRef.current);
    };
  }, [channel?.id, showBannerSignal]);

  // Main tuning effect
  useEffect(() => {
    const video = videoRef.current;
    if (!video || !channel) return;

    const gen = ++tuneGenRef.current;
    if (podTimerRef.current) window.clearTimeout(podTimerRef.current);
    if (retryTimerRef.current) window.clearTimeout(retryTimerRef.current);
    if (hlsRef.current) {
      hlsRef.current.destroy();
      hlsRef.current = null;
    }

    video.onloadedmetadata = null;
    video.onplaying = null;
    video.onended = null;
    video.onerror = null;

    setStatusMessage("");
    setNeedsGesture(false);

    // Community Board static broadcast channel & YouTube embed channel
    if (channel.kind === "board" || channel.kind === "youtube") {
      video.pause();
      video.removeAttribute("src");
      video.load();
      setIsLoading(false);
      onPlayingChange(channel.kind === "youtube");
      return;
    }

    // Pluto TV live HLS channels
    if (channel.kind === "pluto") {
      const rawStreamUrl = channel.pluto ? plutoUrls[channel.pluto] : undefined;
      if (!rawStreamUrl) {
        setIsLoading(false);
        setStatusMessage("Pluto stream URL unavailable for this channel.");
        return;
      }

      setIsLoading(true);
      const proxiedHlsUrl = `/api/btv/hls?url=${encodeURIComponent(rawStreamUrl)}`;

      const markReady = () => {
        if (gen !== tuneGenRef.current) return;
        setIsLoading(false);
        setStatusMessage("");
        setNeedsGesture(false);
      };

      video.onloadeddata = markReady;
      video.oncanplay = markReady;
      video.onplaying = () => {
        if (gen !== tuneGenRef.current) return;
        markReady();
        onPlayingChange(true);
      };

      if (Hls.isSupported()) {
        const hls = new Hls({
          enableWorker: true,
          lowLatencyMode: false,
          startLevel: 0,
          capLevelToPlayerSize: true,
          startFragPrefetch: true,
          maxBufferLength: 10,
          maxMaxBufferLength: 20,
          manifestLoadingTimeOut: 6000,
          fragLoadingTimeOut: 8000,
        });
        hlsRef.current = hls;
        hls.on(Hls.Events.MANIFEST_PARSED, () => {
          if (gen !== tuneGenRef.current) return;
          video.play().catch((err) => {
            if (gen === tuneGenRef.current && err?.name === "NotAllowedError") {
              setIsLoading(false);
              setNeedsGesture(true);
              onPlayingChange(false);
            }
          });
        });
        hls.on(Hls.Events.ERROR, (_event, data) => {
          if (gen !== tuneGenRef.current) return;
          if (data.fatal) {
            if (data.type === Hls.ErrorTypes.NETWORK_ERROR) {
              hls.startLoad();
            } else if (data.type === Hls.ErrorTypes.MEDIA_ERROR) {
              hls.recoverMediaError();
            } else {
              setIsLoading(false);
              setStatusMessage("Live Pluto stream unavailable right now.");
              hls.destroy();
            }
          }
        });
        hls.loadSource(proxiedHlsUrl);
        hls.attachMedia(video);
      } else if (video.canPlayType("application/vnd.apple.mpegurl")) {
        video.src = proxiedHlsUrl;
        video.play().catch((err) => {
          if (gen === tuneGenRef.current && err?.name === "NotAllowedError") {
            setIsLoading(false);
            setNeedsGesture(true);
            onPlayingChange(false);
          }
        });
      } else {
        setIsLoading(false);
        setStatusMessage("HLS playback is not supported in this browser.");
      }

      return () => {
        tuneGenRef.current++;
        if (hlsRef.current) {
          hlsRef.current.destroy();
          hlsRef.current = null;
        }
      };
    }

    // Internet Archive & WeatherStar scheduled playback
    const playAudioOrVideo = (targetChannel: Channel, skipCount: number) => {
      if (gen !== tuneGenRef.current) return;
      const nowSec = Date.now() / 1000;
      const slot = slotAt(targetChannel, schedules, globalAnchor, nowSec);
      if (!slot) {
        setIsLoading(false);
        setStatusMessage("Waiting for channel schedule...");
        return;
      }

      if (targetChannel.kind !== "weather" && slot.item.a && clips.length > 0) {
        const plan = buildPodPlan(
          clips,
          targetChannel.id,
          Math.round(slot.startSec),
          slot.item.d
        );
        let acc = 0;
        let idx = 0;
        for (; idx < plan.length; idx++) {
          if (slot.offsetSec < acc + plan[idx].dur) break;
          acc += plan[idx].dur;
        }
        if (podTimerRef.current) window.clearTimeout(podTimerRef.current);
        podTimerRef.current = window.setTimeout(() => {
          if (gen === tuneGenRef.current) {
            playAudioOrVideo(targetChannel, 0);
          }
        }, Math.max(300, (slot.item.d - slot.offsetSec) * 1000 + 250));

        if (idx < plan.length) {
          const playClipIndex = (clipIdx: number, clipOffset: number) => {
            if (gen !== tuneGenRef.current) return;
            const clip = plan[clipIdx];
            if (!clip) return;
            video.onloadedmetadata = () => {
              if (
                gen === tuneGenRef.current &&
                clipOffset > 1 &&
                Math.abs(video.currentTime - clipOffset) > 2 &&
                clipOffset < (video.duration || 1e9)
              ) {
                video.currentTime = clipOffset;
              }
            };
            video.oncanplay = () => {
              if (gen === tuneGenRef.current) setIsLoading(false);
            };
            video.onplaying = () => {
              if (gen === tuneGenRef.current) {
                setIsLoading(false);
                setNeedsGesture(false);
                onPlayingChange(true);
              }
            };
            video.onended = () => {
              if (gen === tuneGenRef.current && clipIdx + 1 < plan.length) {
                playClipIndex(clipIdx + 1, 0);
              }
            };
            video.onerror = () => {
              if (gen === tuneGenRef.current && clipIdx + 1 < plan.length) {
                playClipIndex(clipIdx + 1, 0);
              }
            };
            video.src = clipOffset > 1 ? `${clip.url}#t=${Math.floor(clipOffset)}` : clip.url;
            video.play().catch((err) => {
              if (err?.name === "NotAllowedError") {
                setIsLoading(false);
                setNeedsGesture(true);
              }
            });
          };
          setIsLoading(false);
          playClipIndex(idx, slot.offsetSec - acc);
          return;
        }
      }

      const schedule = schedules[targetChannel.id];
      let item = slot.item;
      let offset = slot.offsetSec;

      if (schedule && schedule.items.length > 0) {
        let k = 0;
        while (
          k < skipCount + schedule.items.length &&
          badUrlsRef.current.has(item.u + (item._fb ? "#f" : ""))
        ) {
          item = schedule.items[(slot.index + 1 + k) % schedule.items.length];
          offset = 0;
          k++;
        }
      }

      setIsLoading(targetChannel.kind !== "weather");
      const baseSrc = item._fb && item.f ? item.f : item.u;
      // Use HTML5 media fragment #t= so browser seeks directly without buffering 0s first
      const src =
        targetChannel.kind !== "weather" && offset > 2
          ? `${baseSrc}#t=${Math.floor(offset)}`
          : baseSrc;

      video.onloadedmetadata = () => {
        if (gen !== tuneGenRef.current) return;
        if (
          offset > 2 &&
          Math.abs(video.currentTime - offset) > 3 &&
          offset < (video.duration || 1e9)
        ) {
          video.currentTime = offset;
        }
      };

      video.oncanplay = () => {
        if (gen !== tuneGenRef.current) return;
        setIsLoading(false);
        setStatusMessage("");
      };

      video.onplaying = () => {
        if (gen !== tuneGenRef.current) return;
        setIsLoading(false);
        setStatusMessage("");
        setNeedsGesture(false);
        onPlayingChange(true);
      };

      video.onended = () => {
        if (gen === tuneGenRef.current) {
          playAudioOrVideo(targetChannel, 0);
        }
      };

      video.onerror = () => {
        if (gen !== tuneGenRef.current) return;
        if (item.f && !item._fb) {
          item._fb = true;
          playAudioOrVideo(targetChannel, 0);
        } else {
          badUrlsRef.current.add(item.u + (item._fb ? "#f" : ""));
          setIsLoading(false);
          setStatusMessage("Signal interrupted — switching to next program...");
          retryTimerRef.current = window.setTimeout(() => {
            if (gen === tuneGenRef.current) {
              setStatusMessage("");
              playAudioOrVideo(targetChannel, skipCount + 1);
            }
          }, 900);
        }
      };

      video.src = src;
      video.play().catch((err) => {
        if (gen === tuneGenRef.current && err?.name === "NotAllowedError") {
          setIsLoading(false);
          setNeedsGesture(true);
          onPlayingChange(false);
        }
      });
    };

    playAudioOrVideo(channel, 0);

    return () => {
      tuneGenRef.current++;
      if (podTimerRef.current) window.clearTimeout(podTimerRef.current);
      if (retryTimerRef.current) window.clearTimeout(retryTimerRef.current);
      if (hlsRef.current) {
        hlsRef.current.destroy();
        hlsRef.current = null;
      }
    };
  }, [channel?.id, schedules, globalAnchor, clips, plutoUrls]);

  const nowInfo: NowNextInfo | null = channel
    ? getNowNext(channel, schedules, globalAnchor, nowMs / 1000)
    : null;

  const handleResumeGesture = () => {
    const video = videoRef.current;
    if (!video) return;
    setNeedsGesture(false);
    video
      .play()
      .then(() => {
        onPlayingChange(true);
      })
      .catch(() => {});
  };

  return (
    <div
      ref={stageContainerRef}
      onClick={() => {
        if (needsGesture) {
          handleResumeGesture();
        } else {
          onStageClick();
        }
      }}
      className={
        couchMode
          ? "relative flex h-full w-full items-center justify-center overflow-hidden bg-black cursor-pointer select-none"
          : "relative flex w-full items-center justify-center overflow-hidden rounded-xl border border-[#232733] bg-black aspect-video cursor-pointer select-none"
      }
    >
      <div
        className={`relative h-full overflow-hidden transition-all duration-200 ${
          aspect43 ? "aspect-[4/3] w-auto max-w-full" : "w-full"
        }`}
      >
        <video
          ref={videoRef}
          playsInline
          className={`h-full w-full bg-black ${
            aspect43 ? "object-fill" : "object-contain"
          }`}
        />

        {channel?.kind === "weather" && <WeatherStarView nowMs={nowMs} />}

        {channel?.kind === "youtube" && (channel.ytVideoId || channel.ytPlaylistId) && (
          <iframe
            key={channel.id}
            src={
              channel.ytPlaylistId
                ? `https://www.youtube-nocookie.com/embed/videoseries?list=${encodeURIComponent(
                    channel.ytPlaylistId
                  )}&autoplay=1&rel=0&modestbranding=1&mute=${muted ? 1 : 0}`
                : `https://www.youtube-nocookie.com/embed/${encodeURIComponent(
                    channel.ytVideoId!
                  )}?autoplay=1&rel=0&modestbranding=1&mute=${muted ? 1 : 0}`
            }
            title={channel.ytTitle || channel.name}
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
            allowFullScreen
            referrerPolicy="strict-origin-when-cross-origin"
            className="absolute inset-0 z-10 h-full w-full border-0 bg-black"
          />
        )}

        {channel?.kind === "board" && (
          <div className="absolute inset-0 z-10 flex flex-col justify-between bg-gradient-to-br from-[#0F172A] via-[#131D36] to-[#0B0F1A] p-6 sm:p-10">
            <div className="flex items-center justify-between border-b border-white/15 pb-3">
              <span className="font-mono text-xs font-bold tracking-wider text-amber-400">
                CH {channel.num} · {channel.name}
              </span>
              <span className="font-mono text-xs text-[#9CA3AF] tabular-nums">
                {formatClock(nowMs)}
              </span>
            </div>
            <div className="max-w-xl">
              <h2 className="font-display text-2xl font-bold text-white sm:text-4xl">
                {channel.headline || "Community Bulletin"}
              </h2>
              {channel.blurb && (
                <p className="mt-3 text-sm leading-relaxed text-[#D1D5DB] sm:text-base">
                  {channel.blurb}
                </p>
              )}
              {channel.url && (
                <a
                  href={channel.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={(e) => e.stopPropagation()}
                  className="mt-5 inline-flex items-center gap-2 rounded-lg bg-amber-500 px-4 py-2.5 text-sm font-semibold text-[#0A0B0E] hover:bg-amber-400"
                >
                  <span>Visit BackWhenTV Support</span>
                  <ExternalLink className="h-4 w-4" aria-hidden="true" />
                </a>
              )}
            </div>
            <div className="text-xs text-[#9CA3AF]">
              Use CH ▲ or the channel rail to surf all verified live channels.
            </div>
          </div>
        )}

        {scanlines && (
          <div
            aria-hidden="true"
            className="crt-scanlines pointer-events-none absolute inset-0 z-20 opacity-60"
          />
        )}

        {/* Loading / Tuning Overlay */}
        {isLoading &&
          channel?.kind !== "weather" &&
          channel?.kind !== "board" &&
          channel?.kind !== "youtube" &&
          !needsGesture && (
            <div className="absolute inset-0 z-20 flex flex-col items-center justify-center gap-3 bg-[#0A0B0E]/85 text-center">
              <div className="flex h-1.5 w-32 overflow-hidden rounded-full bg-[#232733]">
                <div className="w-1/5 bg-neutral-200" />
                <div className="w-1/5 bg-amber-400" />
                <div className="w-1/5 bg-cyan-400" />
                <div className="w-1/5 bg-emerald-400" />
                <div className="w-1/5 bg-rose-500" />
              </div>
              <div className="font-mono text-sm font-medium text-[#E5E7EB]">
                Tuning Ch {channel?.num} · {channel?.name}
              </div>
            </div>
          )}

        {/* Signal Recovery Message */}
        {statusMessage && (
          <div className="absolute inset-0 z-20 flex flex-col items-center justify-center gap-2 bg-[#0A0B0E]/90 px-6 text-center">
            <Radio className="h-7 w-7 text-amber-400" aria-hidden="true" />
            <p className="font-mono text-sm text-[#F4F4F5]">{statusMessage}</p>
          </div>
        )}

        {/* Click-to-Tune Unblock Overlay */}
        {needsGesture && (
          <div className="absolute inset-0 z-30 flex flex-col items-center justify-center gap-4 bg-[#0A0B0E]/80 px-6 text-center backdrop-blur-[2px]">
            <div className="flex h-14 w-14 items-center justify-center rounded-full bg-amber-500 text-[#0A0B0E]">
              <Play className="ml-0.5 h-6 w-6 fill-current" aria-hidden="true" />
            </div>
            <div>
              <p className="font-display text-xl font-bold text-white">
                Click to Tune In
              </p>
              <p className="mt-1 text-sm text-[#9CA3AF]">
                Ch {channel?.num} · {channel?.name}
                {nowInfo?.currentTitle ? ` · ${nowInfo.currentTitle}` : ""}
              </p>
            </div>
          </div>
        )}

        {/* Direct Number Entry OSD */}
        {digitBuffer && (
          <div className="absolute right-6 top-6 z-30 rounded-lg border border-amber-400/50 bg-[#0A0B0E]/90 px-4 py-2 font-mono text-3xl font-bold tracking-widest text-amber-400 tabular-nums">
            {digitBuffer}
          </div>
        )}

        {/* Channel Banner OSD */}
        {channel && nowInfo && channel.kind !== "board" && (
          <div
            className={`pointer-events-none absolute inset-x-0 bottom-0 z-20 bg-gradient-to-t from-black/90 via-black/65 to-transparent transition-opacity duration-200 ${
              couchMode ? "px-8 pb-7 pt-16" : "px-5 pb-4 pt-12"
            } ${bannerVisible ? "opacity-100" : "opacity-0"}`}
          >
            <div className="flex items-end justify-between gap-4">
              <div className="min-w-0 flex-1">
                <div
                  className={`flex items-center gap-2 font-medium text-amber-300 ${
                    couchMode ? "text-sm sm:text-base" : "text-xs"
                  }`}
                >
                  <span className="font-mono font-bold tabular-nums">
                    CH {channel.num}
                  </span>
                  <span aria-hidden="true">·</span>
                  <span className="truncate text-[#E5E7EB]">{channel.name}</span>
                  {channel.cat && (
                    <>
                      <span aria-hidden="true">·</span>
                      <span className="hidden sm:inline text-[#9CA3AF]">
                        {channel.cat}
                      </span>
                    </>
                  )}
                </div>
                <div
                  className={`mt-1 truncate font-display font-bold text-white ${
                    couchMode ? "text-2xl sm:text-3xl" : "text-lg sm:text-xl"
                  }`}
                >
                  {nowInfo.currentTitle}
                </div>
                {nowInfo.nextTitle && (
                  <div
                    className={`mt-0.5 truncate text-[#D1D5DB] ${
                      couchMode ? "text-sm" : "text-xs"
                    }`}
                  >
                    Up next: {nowInfo.nextTitle}
                  </div>
                )}
              </div>

              <div
                className={`shrink-0 text-right font-mono text-[#D1D5DB] tabular-nums ${
                  couchMode ? "text-sm sm:text-base" : "text-xs"
                }`}
              >
                <div>{formatClock(nowMs)}</div>
                {nowInfo.durationSec > 0 && (
                  <div className="mt-0.5 text-[#9CA3AF]">
                    {formatDuration(nowInfo.durationSec - nowInfo.elapsedSec)} left
                  </div>
                )}
              </div>
            </div>

            {nowInfo.durationSec > 0 && (
              <div className="mt-2.5 h-1 w-full overflow-hidden rounded-full bg-white/15">
                <div
                  className="h-full bg-amber-400 transition-all duration-300"
                  style={{ width: `${nowInfo.progressPct}%` }}
                />
              </div>
            )}

            {couchMode && (
              <div className="mt-2.5 font-mono text-xs text-[#9CA3AF]">
                ↑/↓ Channel · ← Guide · OK Info · M Mute · Esc Exit
              </div>
            )}
          </div>
        )}

        {!channel && (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 text-[#9CA3AF]">
            <Tv className="h-8 w-8" aria-hidden="true" />
            <span className="text-sm">Select a channel to begin watching</span>
          </div>
        )}
      </div>
    </div>
  );
}
