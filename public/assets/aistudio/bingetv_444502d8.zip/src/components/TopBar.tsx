import { Shuffle, Tv } from "lucide-react";
import type { ViewMode } from "../types/tv.ts";
import { PWAInstallButton } from "./PWAInstallButton.tsx";

interface TopBarProps {
  activeView: ViewMode;
  onSelectView: (view: ViewMode) => void;
  onShuffleChannel: () => void;
  onEnterCouchMode: () => void;
  favoritesCount: number;
}

const NAV_ITEMS: { id: ViewMode; label: string }[] = [
  { id: "live", label: "Watch Live" },
  { id: "guide", label: "Channel Guide" },
  { id: "categories", label: "Categories" },
  { id: "favorites", label: "Favorites" },
];

export function TopBar({
  activeView,
  onSelectView,
  onShuffleChannel,
  onEnterCouchMode,
  favoritesCount,
}: TopBarProps) {
  return (
    <header className="sticky top-0 z-30 border-b border-[#232733] bg-[#0A0B0E]/95 backdrop-blur-sm">
      <div className="mx-auto flex h-16 max-w-[1440px] items-center justify-between gap-6 px-4 sm:px-6">
        <button
          type="button"
          onClick={() => onSelectView("live")}
          className="font-display text-xl font-bold tracking-tight text-[#F4F4F5] whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-400 rounded-sm"
        >
          BingeTV
        </button>

        <nav aria-label="Primary navigation" className="flex items-center gap-6 overflow-x-auto">
          {NAV_ITEMS.map((item) => {
            const isActive = activeView === item.id;
            const label =
              item.id === "favorites" && favoritesCount > 0
                ? `${item.label} (${favoritesCount})`
                : item.label;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => onSelectView(item.id)}
                className={`relative py-2 text-sm font-medium whitespace-nowrap shrink-0 transition-colors duration-150 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-400 rounded-sm ${
                  isActive
                    ? "text-[#F4F4F5]"
                    : "text-[#9CA3AF] hover:text-[#F4F4F5]"
                }`}
              >
                {label}
                {isActive && (
                  <span
                    aria-hidden="true"
                    className="absolute inset-x-0 bottom-0 h-0.5 bg-amber-400"
                  />
                )}
              </button>
            );
          })}
        </nav>

        <div className="flex items-center gap-2 shrink-0">
          <PWAInstallButton />
          <button
            type="button"
            onClick={onEnterCouchMode}
            title="Couch Mode (C) — 10-foot TV & remote view"
            className="inline-flex items-center gap-1.5 rounded-lg border border-[#2A2F3D] bg-[#181B23] px-3 py-2 text-sm font-medium text-[#F4F4F5] transition-colors duration-150 hover:bg-[#232733] hover:text-amber-300 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-400"
          >
            <Tv className="h-4 w-4 text-amber-400" aria-hidden="true" />
            <span className="hidden md:inline">Couch Mode</span>
          </button>
          <button
            type="button"
            onClick={onShuffleChannel}
            className="inline-flex items-center gap-2 rounded-lg bg-amber-500 px-3.5 py-2 text-sm font-semibold text-[#0A0B0E] transition-colors duration-150 hover:bg-amber-400 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-300"
          >
            <Shuffle className="h-4 w-4" aria-hidden="true" />
            <span className="hidden sm:inline">Shuffle Channel</span>
            <span className="sm:hidden">Shuffle</span>
          </button>
        </div>
      </div>
    </header>
  );
}
