import { useMemo, useState } from "react";
import { Heart, Search, X } from "lucide-react";
import type { Channel, ChannelSchedule } from "../types/tv.ts";
import { getNowNext } from "../utils/scheduleEngine.ts";

interface ChannelRailProps {
  channels: Channel[];
  schedules: Record<string, ChannelSchedule>;
  globalAnchor: number;
  activeChannelId: string | null;
  favorites: Set<string>;
  onSelectChannel: (channelId: string) => void;
  onToggleFavorite: (channelId: string) => void;
  nowMs: number;
  loading: boolean;
}

export function ChannelRail({
  channels,
  schedules,
  globalAnchor,
  activeChannelId,
  favorites,
  onSelectChannel,
  onToggleFavorite,
  nowMs,
  loading,
}: ChannelRailProps) {
  const [query, setQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("All");

  const categories = useMemo(() => {
    const seen = new Set<string>();
    for (const ch of channels) {
      if (ch.cat) seen.add(ch.cat);
    }
    return ["All", "Favorites", ...Array.from(seen)];
  }, [channels]);

  const nowSec = nowMs / 1000;

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return channels.filter((ch) => {
      if (selectedCategory === "Favorites" && !favorites.has(ch.id)) return false;
      if (
        selectedCategory !== "All" &&
        selectedCategory !== "Favorites" &&
        ch.cat !== selectedCategory
      ) {
        return false;
      }
      if (!q) return true;
      const nowInfo = getNowNext(ch, schedules, globalAnchor, nowSec);
      return (
        String(ch.num).includes(q) ||
        ch.name.toLowerCase().includes(q) ||
        (ch.cat && ch.cat.toLowerCase().includes(q)) ||
        nowInfo.currentTitle.toLowerCase().includes(q)
      );
    });
  }, [channels, selectedCategory, favorites, query, schedules, globalAnchor, nowSec]);

  return (
    <aside
      aria-label="Live channel lineup"
      className="flex h-[560px] flex-col overflow-hidden rounded-xl border border-[#232733] bg-[#12141A] lg:h-[calc(100vh-116px)] lg:min-h-[600px]"
    >
      <div className="border-b border-[#232733] p-4">
        <div className="flex items-center justify-between gap-2">
          <h2 className="font-display text-base font-bold text-[#F4F4F5]">
            Live Channels
          </h2>
          <span className="font-mono text-xs text-[#9CA3AF] tabular-nums">
            {filtered.length} of {channels.length}
          </span>
        </div>

        {/* Search Input */}
        <div className="relative mt-3">
          <Search
            className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-[#6B7280]"
            aria-hidden="true"
          />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search channels or shows..."
            aria-label="Search channels or currently airing shows"
            className="h-10 w-full rounded-lg border border-[#2A2F3D] bg-[#0A0B0E] pl-9 pr-8 text-sm text-[#F4F4F5] placeholder-[#6B7280] focus:border-amber-400 focus:outline-none"
          />
          {query && (
            <button
              type="button"
              onClick={() => setQuery("")}
              aria-label="Clear search"
              className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[#9CA3AF] hover:text-white cursor-pointer"
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </div>

        {/* Category Filter Tabs */}
        <div className="mt-3 flex items-center gap-1.5 overflow-x-auto pb-1">
          {categories.map((cat) => {
            const active = selectedCategory === cat;
            return (
              <button
                key={cat}
                type="button"
                onClick={() => setSelectedCategory(cat)}
                className={`rounded-md px-2.5 py-1.5 text-xs font-medium whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
                  active
                    ? "bg-amber-500 text-[#0A0B0E] font-semibold"
                    : "bg-[#181B23] text-[#9CA3AF] hover:bg-[#232733] hover:text-[#F4F4F5]"
                }`}
              >
                {cat}
              </button>
            );
          })}
        </div>
      </div>

      {/* Scrollable Channel Rows */}
      <div className="flex-1 overflow-y-auto divide-y divide-[#1C202B]">
        {loading && channels.length === 0 ? (
          Array.from({ length: 10 }).map((_, idx) => (
            <div key={idx} className="flex items-center gap-3 px-4 py-3 animate-pulse">
              <div className="h-5 w-9 rounded bg-[#1E222D]" />
              <div className="flex-1 space-y-1.5">
                <div className="h-3.5 w-2/3 rounded bg-[#1E222D]" />
                <div className="h-3 w-4/5 rounded bg-[#181B23]" />
              </div>
            </div>
          ))
        ) : filtered.length === 0 ? (
          <div className="flex h-full flex-col items-center justify-center gap-3 px-6 text-center">
            <p className="text-sm font-medium text-[#D1D5DB]">
              No matching channels found
            </p>
            <p className="text-xs text-[#9CA3AF]">
              {selectedCategory === "Favorites"
                ? "Save channels with the heart icon to build your personal lineup."
                : "Try clearing your search filter or switching categories."}
            </p>
            <button
              type="button"
              onClick={() => {
                setQuery("");
                setSelectedCategory("All");
              }}
              className="rounded-lg border border-[#2A2F3D] bg-[#181B23] px-3.5 py-2 text-xs font-medium text-[#F4F4F5] hover:bg-[#232733] cursor-pointer"
            >
              Show All Channels
            </button>
          </div>
        ) : (
          filtered.map((ch) => {
            const isTuned = ch.id === activeChannelId;
            const isFav = favorites.has(ch.id);
            const nowInfo = getNowNext(ch, schedules, globalAnchor, nowSec);

            return (
              <div
                key={ch.id}
                className={`group flex items-stretch transition-colors ${
                  isTuned
                    ? "bg-amber-500/10"
                    : "hover:bg-[#181B23]"
                }`}
              >
                <button
                  type="button"
                  onClick={() => onSelectChannel(ch.id)}
                  className="flex min-w-0 flex-1 items-start gap-3 px-4 py-3 text-left cursor-pointer"
                >
                  <span
                    className={`mt-0.5 w-9 shrink-0 font-mono text-sm font-bold tabular-nums ${
                      isTuned ? "text-amber-400" : "text-[#9CA3AF] group-hover:text-[#F4F4F5]"
                    }`}
                  >
                    {String(ch.num).padStart(3, "0")}
                  </span>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <span
                        className={`truncate text-sm font-semibold ${
                          isTuned ? "text-amber-300" : "text-[#F4F4F5]"
                        }`}
                      >
                        {ch.name}
                      </span>
                    </div>
                    <div className="mt-0.5 truncate text-xs text-[#9CA3AF]">
                      {nowInfo.currentTitle}
                    </div>
                    {nowInfo.durationSec > 0 && (
                      <div className="mt-2 h-0.5 w-full overflow-hidden rounded-full bg-[#232733]">
                        <div
                          className={`h-full ${
                            isTuned ? "bg-amber-400" : "bg-[#4B5563]"
                          }`}
                          style={{ width: `${nowInfo.progressPct}%` }}
                        />
                      </div>
                    )}
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => onToggleFavorite(ch.id)}
                  aria-label={
                    isFav
                      ? `Remove ${ch.name} from favorites`
                      : `Save ${ch.name} to favorites`
                  }
                  className="flex w-10 shrink-0 items-center justify-center text-[#6B7280] transition-colors hover:text-amber-400 cursor-pointer"
                >
                  <Heart
                    className={`h-3.5 w-3.5 ${
                      isFav ? "fill-amber-400 text-amber-400" : ""
                    }`}
                    aria-hidden="true"
                  />
                </button>
              </div>
            );
          })
        )}
      </div>
    </aside>
  );
}
