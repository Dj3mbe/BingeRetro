import { useEffect, useMemo, useRef, useState } from "react";
import {
  ChevronDown,
  ChevronUp,
  Heart,
  List,
  Maximize,
  Monitor,
  Shuffle,
  Smartphone,
  Tv,
  Volume2,
  VolumeX,
  X,
} from "lucide-react";
import type { Channel, ChannelSchedule } from "../types/tv.ts";
import { formatClock, getNowNext } from "../utils/scheduleEngine.ts";

interface CouchModeOverlayProps {
  channels: Channel[];
  schedules: Record<string, ChannelSchedule>;
  globalAnchor: number;
  activeChannelId: string | null;
  favorites: Set<string>;
  guideOpen: boolean;
  onSetGuideOpen: (open: boolean) => void;
  onSelectChannel: (channelId: string) => void;
  onStepChannel: (delta: number) => void;
  onShuffleChannel: () => void;
  onToggleFavorite: (channelId: string) => void;
  volume: number;
  muted: boolean;
  onToggleMute: () => void;
  aspect43: boolean;
  onToggleAspect43: () => void;
  scanlines: boolean;
  onToggleScanlines: () => void;
  onFullscreen: () => void;
  onOpenTvSetup: () => void;
  onExitCouchMode: () => void;
  nowMs: number;
}

export function CouchModeOverlay({
  channels,
  schedules,
  globalAnchor,
  activeChannelId,
  favorites,
  guideOpen,
  onSetGuideOpen,
  onSelectChannel,
  onStepChannel,
  onShuffleChannel,
  onToggleFavorite,
  muted,
  onToggleMute,
  aspect43,
  onToggleAspect43,
  scanlines,
  onToggleScanlines,
  onFullscreen,
  onOpenTvSetup,
  onExitCouchMode,
  nowMs,
}: CouchModeOverlayProps) {
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [focusedIndex, setFocusedIndex] = useState(0);
  const [hudVisible, setHudVisible] = useState(true);

  const hudTimerRef = useRef<number | null>(null);
  const rowRefs = useRef<Array<HTMLDivElement | null>>([]);
  const nowSec = nowMs / 1000;

  const categories = useMemo(() => {
    const seen = new Set<string>();
    for (const ch of channels) {
      if (ch.cat) seen.add(ch.cat);
    }
    return ["All", "Favorites", ...Array.from(seen)];
  }, [channels]);

  const filteredChannels = useMemo(() => {
    return channels.filter((ch) => {
      if (selectedCategory === "Favorites") return favorites.has(ch.id);
      if (selectedCategory !== "All") return ch.cat === selectedCategory;
      return true;
    });
  }, [channels, selectedCategory, favorites]);

  // Show minimal edge HUD briefly on pointer move/touch when drawer is closed
  useEffect(() => {
    if (guideOpen) {
      setHudVisible(false);
      return;
    }

    const revealHud = () => {
      setHudVisible(true);
      if (hudTimerRef.current) window.clearTimeout(hudTimerRef.current);
      hudTimerRef.current = window.setTimeout(() => {
        setHudVisible(false);
      }, 3200);
    };

    revealHud();
    window.addEventListener("mousemove", revealHud);
    window.addEventListener("touchstart", revealHud);
    return () => {
      if (hudTimerRef.current) window.clearTimeout(hudTimerRef.current);
      window.removeEventListener("mousemove", revealHud);
      window.removeEventListener("touchstart", revealHud);
    };
  }, [guideOpen, activeChannelId]);

  // Snap D-pad focus to the currently playing channel when opening the drawer
  useEffect(() => {
    if (!guideOpen) return;
    const idx = filteredChannels.findIndex((c) => c.id === activeChannelId);
    setFocusedIndex(idx >= 0 ? idx : 0);
  }, [guideOpen, activeChannelId, selectedCategory]);

  // Smoothly scroll D-pad focused row into view
  useEffect(() => {
    if (!guideOpen) return;
    const el = rowRefs.current[focusedIndex];
    el?.scrollIntoView({ block: "nearest", behavior: "smooth" });
  }, [guideOpen, focusedIndex]);

  // D-pad remote keyboard handler while drawer is open
  useEffect(() => {
    if (!guideOpen) return;

    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === "ArrowDown") {
        e.preventDefault();
        e.stopPropagation();
        if (filteredChannels.length === 0) return;
        setFocusedIndex((i) => (i + 1) % filteredChannels.length);
      } else if (e.key === "ArrowUp") {
        e.preventDefault();
        e.stopPropagation();
        if (filteredChannels.length === 0) return;
        setFocusedIndex(
          (i) => (i - 1 + filteredChannels.length) % filteredChannels.length
        );
      } else if (e.key === "ArrowRight") {
        e.preventDefault();
        e.stopPropagation();
        const catIdx = categories.indexOf(selectedCategory);
        const nextCat = categories[(catIdx + 1) % categories.length];
        setSelectedCategory(nextCat);
        setFocusedIndex(0);
      } else if (e.key === "ArrowLeft") {
        e.preventDefault();
        e.stopPropagation();
        const catIdx = categories.indexOf(selectedCategory);
        const prevCat =
          categories[(catIdx - 1 + categories.length) % categories.length];
        setSelectedCategory(prevCat);
        setFocusedIndex(0);
      } else if (e.key === "Enter" || e.key === " ") {
        e.preventDefault();
        e.stopPropagation();
        const target = filteredChannels[focusedIndex];
        if (target) {
          onSelectChannel(target.id);
          onSetGuideOpen(false);
        }
      } else if (e.key === "Escape" || e.key === "Backspace") {
        e.preventDefault();
        e.stopPropagation();
        onSetGuideOpen(false);
      }
    };

    window.addEventListener("keydown", onKeyDown, true);
    return () => window.removeEventListener("keydown", onKeyDown, true);
  }, [
    guideOpen,
    filteredChannels,
    focusedIndex,
    categories,
    selectedCategory,
    onSelectChannel,
    onSetGuideOpen,
  ]);

  return (
    <>
      {/* Subtle auto-hiding top edge controls for touch / mouse users in Couch Mode */}
      {!guideOpen && (
        <div
          className={`pointer-events-none fixed inset-x-0 top-0 z-30 flex items-center justify-between gap-3 bg-gradient-to-b from-black/80 via-black/40 to-transparent px-5 py-4 transition-opacity duration-300 ${
            hudVisible ? "opacity-100" : "opacity-0"
          }`}
        >
          <div className="pointer-events-auto flex items-center gap-2">
            <button
              type="button"
              onClick={() => onSetGuideOpen(true)}
              className="inline-flex items-center gap-2 rounded-lg border border-white/20 bg-[#0A0B0E]/85 px-4 py-2.5 text-sm font-semibold text-white backdrop-blur-sm hover:border-amber-400 hover:text-amber-300 cursor-pointer"
            >
              <List className="h-4 w-4 text-amber-400" aria-hidden="true" />
              <span>TV Guide (←)</span>
            </button>
            <div className="flex items-center overflow-hidden rounded-lg border border-white/20 bg-[#0A0B0E]/85 backdrop-blur-sm">
              <button
                type="button"
                onClick={() => onStepChannel(-1)}
                aria-label="Channel down"
                className="flex items-center gap-1 px-3 py-2.5 text-sm font-semibold text-white hover:bg-white/10 cursor-pointer"
              >
                <ChevronDown className="h-4 w-4" aria-hidden="true" />
                <span>CH</span>
              </button>
              <button
                type="button"
                onClick={() => onStepChannel(1)}
                aria-label="Channel up"
                className="flex items-center gap-1 border-l border-white/15 px-3 py-2.5 text-sm font-semibold text-white hover:bg-white/10 cursor-pointer"
              >
                <span>CH</span>
                <ChevronUp className="h-4 w-4" aria-hidden="true" />
              </button>
            </div>
            <button
              type="button"
              onClick={onShuffleChannel}
              aria-label="Shuffle channel"
              className="hidden sm:inline-flex items-center gap-1.5 rounded-lg border border-white/20 bg-[#0A0B0E]/85 px-3.5 py-2.5 text-sm font-medium text-white backdrop-blur-sm hover:border-amber-400 cursor-pointer"
            >
              <Shuffle className="h-4 w-4 text-amber-400" aria-hidden="true" />
              <span>Shuffle</span>
            </button>
          </div>

          <div className="pointer-events-auto flex items-center gap-2">
            <button
              type="button"
              onClick={onToggleMute}
              aria-label={muted ? "Unmute" : "Mute"}
              className="rounded-lg border border-white/20 bg-[#0A0B0E]/85 p-2.5 text-white backdrop-blur-sm hover:border-amber-400 cursor-pointer"
            >
              {muted ? (
                <VolumeX className="h-4 w-4 text-red-400" aria-hidden="true" />
              ) : (
                <Volume2 className="h-4 w-4" aria-hidden="true" />
              )}
            </button>
            <button
              type="button"
              onClick={onFullscreen}
              aria-label="Toggle fullscreen"
              className="hidden sm:inline-flex rounded-lg border border-white/20 bg-[#0A0B0E]/85 p-2.5 text-white backdrop-blur-sm hover:border-amber-400 cursor-pointer"
            >
              <Maximize className="h-4 w-4" aria-hidden="true" />
            </button>
            <button
              type="button"
              onClick={onExitCouchMode}
              className="inline-flex items-center gap-1.5 rounded-lg border border-white/20 bg-[#0A0B0E]/85 px-3.5 py-2.5 text-sm font-semibold text-white backdrop-blur-sm hover:border-amber-400 cursor-pointer"
            >
              <X className="h-4 w-4" aria-hidden="true" />
              <span>Exit TV Mode</span>
            </button>
          </div>
        </div>
      )}

      {/* 10-Foot Slide-Out Channel Guide Drawer */}
      {guideOpen && (
        <div
          className="fixed inset-0 z-40 flex bg-black/55 backdrop-blur-[2px]"
          onClick={() => onSetGuideOpen(false)}
        >
          <aside
            aria-label="Couch Mode Channel Guide"
            onClick={(e) => e.stopPropagation()}
            className="flex h-full w-full max-w-2xl flex-col border-r border-[#232733] bg-[#0A0B0E]/95 shadow-2xl"
          >
            {/* Header */}
            <div className="flex items-center justify-between border-b border-[#232733] px-6 py-4">
              <div className="flex items-center gap-3">
                <Tv className="h-5 w-5 text-amber-400" aria-hidden="true" />
                <div>
                  <h2 className="font-display text-xl font-bold text-[#F4F4F5]">
                    BingeTV · Couch Mode
                  </h2>
                  <p className="text-xs text-[#9CA3AF]">
                    {filteredChannels.length} channels in{" "}
                    <span className="text-amber-400">{selectedCategory}</span>
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <span className="font-mono text-sm font-semibold text-[#D1D5DB] tabular-nums">
                  {formatClock(nowMs)}
                </span>
                <button
                  type="button"
                  onClick={() => onSetGuideOpen(false)}
                  aria-label="Close Couch Mode guide"
                  className="rounded-lg border border-[#2A2F3D] bg-[#181B23] p-2 text-[#E5E7EB] hover:bg-[#232733] cursor-pointer"
                >
                  <X className="h-5 w-5" aria-hidden="true" />
                </button>
              </div>
            </div>

            {/* Category Strip (← / → D-pad navigable) */}
            <div className="flex items-center gap-2 overflow-x-auto border-b border-[#232733] px-6 py-3">
              {categories.map((cat) => {
                const active = selectedCategory === cat;
                return (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => {
                      setSelectedCategory(cat);
                      setFocusedIndex(0);
                    }}
                    className={`rounded-lg px-3.5 py-2 text-sm font-semibold whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
                      active
                        ? "bg-amber-500 text-[#0A0B0E]"
                        : "bg-[#14171F] text-[#9CA3AF] hover:bg-[#1E222D] hover:text-white"
                    }`}
                  >
                    {cat}
                  </button>
                );
              })}
            </div>

            {/* 10-Foot Channel List */}
            <div className="flex-1 overflow-y-auto divide-y divide-[#1A1E29] px-3 py-2">
              {filteredChannels.length === 0 ? (
                <div className="flex h-full flex-col items-center justify-center p-8 text-center">
                  <p className="text-base font-medium text-[#D1D5DB]">
                    No channels in {selectedCategory}
                  </p>
                  <button
                    type="button"
                    onClick={() => setSelectedCategory("All")}
                    className="mt-4 rounded-lg bg-amber-500 px-4 py-2 text-sm font-semibold text-[#0A0B0E] cursor-pointer"
                  >
                    Show All Channels
                  </button>
                </div>
              ) : (
                filteredChannels.map((ch, idx) => {
                  const isTuned = ch.id === activeChannelId;
                  const isFocused = idx === focusedIndex;
                  const isFav = favorites.has(ch.id);
                  const nowInfo = getNowNext(ch, schedules, globalAnchor, nowSec);

                  return (
                    <div
                      key={ch.id}
                      ref={(el) => {
                        rowRefs.current[idx] = el;
                      }}
                      className={`my-1 flex items-center gap-3 rounded-xl px-4 py-3.5 transition-all ${
                        isFocused
                          ? "bg-amber-500/20 ring-2 ring-amber-400"
                          : isTuned
                          ? "bg-[#171A24]"
                          : "hover:bg-[#141720]"
                      }`}
                    >
                      <button
                        type="button"
                        onClick={() => {
                          onSelectChannel(ch.id);
                          onSetGuideOpen(false);
                        }}
                        onMouseEnter={() => setFocusedIndex(idx)}
                        className="flex min-w-0 flex-1 items-center gap-4 text-left cursor-pointer"
                      >
                        <span
                          className={`w-12 shrink-0 font-mono text-xl font-bold tabular-nums ${
                            isTuned || isFocused
                              ? "text-amber-400"
                              : "text-[#9CA3AF]"
                          }`}
                        >
                          {String(ch.num).padStart(3, "0")}
                        </span>
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-2">
                            <span className="truncate font-display text-lg font-bold text-[#F4F4F5]">
                              {ch.name}
                            </span>
                            {isTuned && (
                              <span className="text-xs font-mono font-semibold text-amber-400">
                                · LIVE
                              </span>
                            )}
                          </div>
                          <div className="mt-0.5 truncate text-sm text-[#D1D5DB]">
                            {nowInfo.currentTitle}
                          </div>
                          {nowInfo.durationSec > 0 && (
                            <div className="mt-2 h-1 w-full overflow-hidden rounded-full bg-[#232733]">
                              <div
                                className="h-full bg-amber-400"
                                style={{ width: `${nowInfo.progressPct}%` }}
                              />
                            </div>
                          )}
                        </div>
                      </button>

                      <button
                        type="button"
                        onClick={() => onToggleFavorite(ch.id)}
                        aria-label={
                          isFav
                            ? `Remove ${ch.name} from favorites`
                            : `Save ${ch.name} to favorites`
                        }
                        className="rounded-lg p-2.5 text-[#9CA3AF] hover:bg-[#1E222D] hover:text-amber-400 cursor-pointer"
                      >
                        <Heart
                          className={`h-5 w-5 ${
                            isFav ? "fill-amber-400 text-amber-400" : ""
                          }`}
                          aria-hidden="true"
                        />
                      </button>
                    </div>
                  );
                })
              )}
            </div>

            {/* Bottom Quick Settings & Remote Legend */}
            <div className="border-t border-[#232733] bg-[#0E1016] px-6 py-3.5">
              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={onToggleMute}
                  className="inline-flex items-center gap-1.5 rounded-lg border border-[#2A2F3D] bg-[#181B23] px-3 py-2 text-xs font-semibold text-[#E5E7EB] hover:bg-[#232733] cursor-pointer"
                >
                  {muted ? (
                    <VolumeX className="h-3.5 w-3.5 text-red-400" />
                  ) : (
                    <Volume2 className="h-3.5 w-3.5" />
                  )}
                  <span>{muted ? "Unmute" : "Mute"}</span>
                </button>
                <button
                  type="button"
                  onClick={onToggleAspect43}
                  className={`inline-flex items-center gap-1.5 rounded-lg border px-3 py-2 text-xs font-semibold cursor-pointer ${
                    aspect43
                      ? "border-amber-500/60 bg-amber-500/15 text-amber-300"
                      : "border-[#2A2F3D] bg-[#181B23] text-[#E5E7EB] hover:bg-[#232733]"
                  }`}
                >
                  <Monitor className="h-3.5 w-3.5" />
                  <span>{aspect43 ? "4:3" : "16:9"}</span>
                </button>
                <button
                  type="button"
                  onClick={onToggleScanlines}
                  className={`inline-flex items-center gap-1.5 rounded-lg border px-3 py-2 text-xs font-semibold cursor-pointer ${
                    scanlines
                      ? "border-amber-500/60 bg-amber-500/15 text-amber-300"
                      : "border-[#2A2F3D] bg-[#181B23] text-[#E5E7EB] hover:bg-[#232733]"
                  }`}
                >
                  <Tv className="h-3.5 w-3.5" />
                  <span>CRT</span>
                </button>
                <button
                  type="button"
                  onClick={onOpenTvSetup}
                  className="inline-flex items-center gap-1.5 rounded-lg border border-[#2A2F3D] bg-[#181B23] px-3 py-2 text-xs font-semibold text-[#E5E7EB] hover:bg-[#232733] cursor-pointer"
                >
                  <Smartphone className="h-3.5 w-3.5 text-amber-400" />
                  <span>APK / TV Setup</span>
                </button>
                <button
                  type="button"
                  onClick={onExitCouchMode}
                  className="ml-auto inline-flex items-center gap-1.5 rounded-lg bg-amber-500 px-3.5 py-2 text-xs font-semibold text-[#0A0B0E] hover:bg-amber-400 cursor-pointer"
                >
                  <span>Exit Couch Mode</span>
                </button>
              </div>
              <p className="mt-2.5 font-mono text-[11px] text-[#9CA3AF]">
                Remote D-pad: ↑/↓ Select channel · ←/→ Switch category · OK Watch · Esc Close
              </p>
            </div>
          </aside>
        </div>
      )}
    </>
  );
}
