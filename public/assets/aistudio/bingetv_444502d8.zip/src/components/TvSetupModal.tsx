import { useState } from "react";
import { Check, Copy, Smartphone, Tv, X } from "lucide-react";

interface TvSetupModalProps {
  open: boolean;
  onClose: () => void;
  onEnterCouchMode: () => void;
}

export function TvSetupModal({
  open,
  onClose,
  onEnterCouchMode,
}: TvSetupModalProps) {
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  if (!open) return null;

  const baseUrl =
    typeof window !== "undefined" ? window.location.origin : "";
  const tvUrl = `${baseUrl}/?mode=tv`;

  const copyText = (key: string, value: string) => {
    navigator.clipboard?.writeText(value).catch(() => {});
    setCopiedKey(key);
    window.setTimeout(() => setCopiedKey(null), 1800);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-xs"
      onClick={onClose}
    >
      <div
        className="w-full max-w-xl rounded-xl border border-[#232733] bg-[#12141A] p-6 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-4 border-b border-[#232733] pb-4">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-500/15 text-amber-400">
              <Smartphone className="h-5 w-5" aria-hidden="true" />
            </div>
            <div>
              <h2 className="font-display text-lg font-bold text-[#F4F4F5]">
                Android APK &amp; TV Sideload Guide
              </h2>
              <p className="text-xs text-[#9CA3AF]">
                BingeTV is PWA-ready for Android phones, Google TV, and Fire TV
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close TV and APK setup guide"
            className="rounded-lg p-1.5 text-[#9CA3AF] hover:bg-[#1E222D] hover:text-white cursor-pointer"
          >
            <X className="h-5 w-5" aria-hidden="true" />
          </button>
        </div>

        <div className="mt-4 space-y-4 text-sm text-[#D1D5DB]">
          <div className="rounded-lg border border-[#232733] bg-[#0A0B0E] p-3.5">
            <div className="text-xs font-semibold text-amber-400">
              Direct Couch Mode Launch URL (for TV APK / TV Browser)
            </div>
            <div className="mt-2 flex items-center justify-between gap-2">
              <code className="truncate font-mono text-xs text-[#F4F4F5]">
                {tvUrl}
              </code>
              <button
                type="button"
                onClick={() => copyText("tv", tvUrl)}
                className="inline-flex shrink-0 items-center gap-1.5 rounded-md border border-[#2A2F3D] bg-[#181B23] px-2.5 py-1.5 text-xs font-medium text-[#E5E7EB] hover:bg-[#232733] cursor-pointer"
              >
                {copiedKey === "tv" ? (
                  <>
                    <Check className="h-3.5 w-3.5 text-emerald-400" />
                    <span>Copied</span>
                  </>
                ) : (
                  <>
                    <Copy className="h-3.5 w-3.5" />
                    <span>Copy</span>
                  </>
                )}
              </button>
            </div>
          </div>

          <div className="space-y-2">
            <h3 className="font-display text-sm font-bold text-[#F4F4F5]">
              Step 1 — Create the APK (on phone or computer)
            </h3>
            <ol className="space-y-1.5 text-xs leading-relaxed text-[#9CA3AF]">
              <li>
                1. Click <strong className="text-[#E5E7EB]">Share / Publish</strong> in AI Studio so your app URL works without login.
              </li>
              <li>
                2. Open <strong className="text-[#E5E7EB]">pwabuilder.com</strong>, paste your Shared App URL (set Start URL to <code className="text-amber-300">/?mode=tv</code> for Couch Mode), and click <strong className="text-[#E5E7EB]">Package for Stores → Android → Download</strong>.
              </li>
              <li>
                3. Unzip the download to get the <code className="text-[#E5E7EB]">.apk</code> file.
              </li>
            </ol>
          </div>

          <div className="space-y-2">
            <h3 className="font-display text-sm font-bold text-[#F4F4F5]">
              Step 2 — Install with the Downloader App on Your TV
            </h3>
            <ol className="space-y-1.5 text-xs leading-relaxed text-[#9CA3AF]">
              <li>
                1. Upload the <code className="text-[#E5E7EB]">.apk</code> to a direct-download link (e.g. GitHub Releases or Dropbox with <code className="text-[#E5E7EB]">?dl=1</code>).
              </li>
              <li>
                2. Go to <strong className="text-[#E5E7EB]">go.aftvnews.com</strong> and paste that <code className="text-[#E5E7EB]">.apk</code> link (or paste your <code className="text-amber-300">/?mode=tv</code> URL to skip building an APK and open directly in Downloader&apos;s browser). You&apos;ll get a short <strong className="text-[#E5E7EB]">6-digit Downloader code</strong>.
              </li>
              <li>
                3. On your TV, open <strong className="text-[#E5E7EB]">Downloader</strong>, enter the 6-digit code, and press <strong className="text-[#E5E7EB]">Go</strong> to download &amp; install.
              </li>
            </ol>
          </div>
        </div>

        <div className="mt-6 flex flex-wrap items-center justify-end gap-2.5 border-t border-[#232733] pt-4">
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg border border-[#2A2F3D] bg-[#181B23] px-4 py-2 text-xs font-semibold text-[#E5E7EB] hover:bg-[#232733] cursor-pointer"
          >
            Close
          </button>
          <button
            type="button"
            onClick={() => {
              onClose();
              onEnterCouchMode();
            }}
            className="inline-flex items-center gap-2 rounded-lg bg-amber-500 px-4 py-2 text-xs font-semibold text-[#0A0B0E] hover:bg-amber-400 cursor-pointer"
          >
            <Tv className="h-4 w-4" aria-hidden="true" />
            <span>Launch Couch Mode Now</span>
          </button>
        </div>
      </div>
    </div>
  );
}
