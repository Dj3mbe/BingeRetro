import { useMemo, useState } from "react";
import { ChevronLeft, ChevronRight, Play, Search, X } from "lucide-react";
import type { Channel, ChannelSchedule, ScheduleItem } from "../types/tv.ts";
import {
  buildEpgWindow,
  formatClock,
  formatDuration,
} from "../utils/scheduleEngine.ts";

interface EpgGuideProps {
  channels: Channel[];
  schedules: Record<string, ChannelSchedule>;
  globalAnchor: number;
  activeChannelId: string | null;
  onTuneChannel: (channelId: string) => void;
  nowMs: number;
}

const WINDOW_HOURS = 3;
const SLOT_MINUTES = 30;
const PIXELS_PER_MINUTE = 6; // 180px per 30m, 1080px for 3 hours

export function EpgGuide({
  channels,
  schedules,
  globalAnchor,
  activeChannelId,
  onTuneChannel,
  nowMs,
}: EpgGuideProps) {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("All");
  const [hourOffset, setHourOffset] = useState(0);
  const [selectedUpcoming, setSelectedUpcoming] = useState<{
    channel: Channel;
    item: ScheduleItem;
    startSec: number;
    endSec: number;
  } | null>(null);

  const nowSec = nowMs / 1000;

  // Align guide start to the current 30-minute boundary + offset
  const windowStartSec = useMemo(() => {
    const baseHalfHour = Math.floor(nowSec / 1800) * 1800;
    return baseHalfHour + hourOffset * 3600;
  }, [Math.floor(nowSec / 60), hourOffset]);

  const windowEndSec = windowStartSec + WINDOW_HOURS * 3600;
  const totalWidthPx = WINDOW_HOURS * 60 * PIXELS_PER_MINUTE;

  const categories = useMemo(() => {
    const set = new Set<string>();
    for (const ch of channels) {
      if (ch.cat) set.add(ch.cat);
    }
    return ["All", ...Array.from(set)];
  }, [channels]);

  const filteredChannels = useMemo(() => {
    const q = query.trim().toLowerCase();
    return channels.filter((ch) => {
      if (category !== "All" && ch.cat !== category) return false;
      if (!q) return true;
      return (
        String(ch.num).includes(q) ||
        ch.name.toLowerCase().includes(q) ||
        (ch.blurb && ch.blurb.toLowerCase().includes(q))
      );
    });
  }, [channels, category, query]);

  const timeTicks = useMemo(() => {
    const ticks: number[] = [];
    for (let t = windowStartSec; t < windowEndSec; t += SLOT_MINUTES * 60) {
      ticks.push(t);
    }
    return ticks;
  }, [windowStartSec, windowEndSec]);

  const nowLineLeftPx =
    nowSec >= windowStartSec && nowSec <= windowEndSec
      ? ((nowSec - windowStartSec) / 60) * PIXELS_PER_MINUTE
      : null;

  return (
    <section className="mx-auto max-w-[1440px] px-4 py-6 sm:px-6">
      <div className="flex flex-col gap-4 border-b border-[#232733] pb-5 lg:flex-row lg:items-end lg:justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold text-[#F4F4F5] sm:text-3xl">
            Channel Guide
          </h1>
          <p className="mt-1 text-sm text-[#9CA3AF]">
            Synchronized 24/7 broadcast schedule · Click any live program to tune immediately
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div className="relative">
            <Search
              className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-[#6B7280]"
              aria-hidden="true"
            />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Filter channels..."
              aria-label="Filter guide channels"
              className="h-10 w-56 rounded-lg border border-[#2A2F3D] bg-[#12141A] pl-9 pr-8 text-sm text-[#F4F4F5] placeholder-[#6B7280] focus:border-amber-400 focus:outline-none"
            />
            {query && (
              <button
                type="button"
                onClick={() => setQuery("")}
                aria-label="Clear filter"
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[#9CA3AF] hover:text-white cursor-pointer"
              >
                <X className="h-4 w-4" />
              </button>
            )}
          </div>

          <div className="flex items-center rounded-lg border border-[#2A2F3D] bg-[#12141A]">
            <button
              type="button"
              onClick={() => setHourOffset((h) => Math.max(-2, h - 1))}
              className="flex h-10 items-center gap-1 px-3 text-xs font-medium text-[#D1D5DB] hover:bg-[#181B23] cursor-pointer"
            >
              <ChevronLeft className="h-4 w-4" aria-hidden="true" />
              <span>Earlier</span>
            </button>
            <button
              type="button"
              onClick={() => setHourOffset(0)}
              className={`h-10 border-x border-[#2A2F3D] px-3 text-xs font-semibold cursor-pointer ${
                hourOffset === 0
                  ? "text-amber-400"
                  : "text-[#D1D5DB] hover:bg-[#181B23]"
              }`}
            >
              Now
            </button>
            <button
              type="button"
              onClick={() => setHourOffset((h) => Math.min(6, h + 1))}
              className="flex h-10 items-center gap-1 px-3 text-xs font-medium text-[#D1D5DB] hover:bg-[#181B23] cursor-pointer"
            >
              <span>Later</span>
              <ChevronRight className="h-4 w-4" aria-hidden="true" />
            </button>
          </div>
        </div>
      </div>

      {/* Category Filter Strip */}
      <div className="mt-4 flex items-center gap-1.5 overflow-x-auto pb-2">
        {categories.map((cat) => (
          <button
            key={cat}
            type="button"
            onClick={() => setCategory(cat)}
            className={`rounded-md px-3 py-1.5 text-xs font-medium whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
              category === cat
                ? "bg-amber-500 text-[#0A0B0E] font-semibold"
                : "bg-[#12141A] text-[#9CA3AF] border border-[#232733] hover:text-[#F4F4F5]"
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Upcoming Program Detail Bar (when user inspects a future slot) */}
      {selectedUpcoming && (
        <div className="mt-4 flex flex-col gap-3 rounded-xl border border-[#2A2F3D] bg-[#12141A] p-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="min-w-0">
            <div className="flex items-center gap-2 text-xs text-amber-400">
              <span className="font-mono font-bold tabular-nums">
                Ch {selectedUpcoming.channel.num}
              </span>
              <span aria-hidden="true">·</span>
              <span>{selectedUpcoming.channel.name}</span>
              <span aria-hidden="true">·</span>
              <span className="font-mono text-[#D1D5DB] tabular-nums">
                {formatClock(selectedUpcoming.startSec * 1000)} –{" "}
                {formatClock(selectedUpcoming.endSec * 1000)}
              </span>
            </div>
            <div className="mt-1 font-display text-base font-bold text-white">
              {selectedUpcoming.item.t}
            </div>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => onTuneChannel(selectedUpcoming.channel.id)}
              className="inline-flex items-center gap-1.5 rounded-lg bg-amber-500 px-3.5 py-2 text-xs font-semibold text-[#0A0B0E] hover:bg-amber-400 cursor-pointer"
            >
              <Play className="h-3.5 w-3.5 fill-current" aria-hidden="true" />
              <span>Watch Channel Live</span>
            </button>
            <button
              type="button"
              onClick={() => setSelectedUpcoming(null)}
              aria-label="Close program preview"
              className="rounded-lg border border-[#2A2F3D] px-3 py-2 text-xs text-[#9CA3AF] hover:text-white cursor-pointer"
            >
              Dismiss
            </button>
          </div>
        </div>
      )}

      {/* EPG Timeline Grid */}
      <div className="mt-4 overflow-hidden rounded-xl border border-[#232733] bg-[#12141A]">
        <div className="overflow-x-auto">
          <div style={{ minWidth: `${240 + totalWidthPx}px` }}>
            {/* Time Ruler Header */}
            <div className="flex border-b border-[#232733] bg-[#161922]">
              <div className="sticky left-0 z-20 flex h-11 w-60 shrink-0 items-center border-r border-[#232733] bg-[#161922] px-4 text-xs font-semibold text-[#9CA3AF]">
                Channel ({filteredChannels.length})
              </div>
              <div className="relative flex flex-1" style={{ width: `${totalWidthPx}px` }}>
                {timeTicks.map((tick) => (
                  <div
                    key={tick}
                    style={{ width: `${SLOT_MINUTES * PIXELS_PER_MINUTE}px` }}
                    className="flex h-11 shrink-0 items-center border-r border-[#232733] px-3 font-mono text-xs font-medium text-[#D1D5DB] tabular-nums"
                  >
                    {formatClock(tick * 1000)}
                  </div>
                ))}
                {nowLineLeftPx !== null && (
                  <div
                    aria-hidden="true"
                    style={{ left: `${nowLineLeftPx}px` }}
                    className="absolute bottom-0 top-0 z-10 w-0.5 bg-amber-400"
                  />
                )}
              </div>
            </div>

            {/* Channel Rows */}
            <div className="max-h-[62vh] overflow-y-auto divide-y divide-[#1D212C]">
              {filteredChannels.length === 0 ? (
                <div className="px-6 py-12 text-center text-sm text-[#9CA3AF]">
                  No channels match your current filter.
                </div>
              ) : (
                filteredChannels.map((ch) => {
                  const isTuned = ch.id === activeChannelId;
                  const blocks = buildEpgWindow(
                    ch,
                    schedules,
                    globalAnchor,
                    windowStartSec,
                    windowEndSec,
                    nowSec
                  );

                  return (
                    <div key={ch.id} className="flex h-14">
                      {/* Sticky Channel Cell */}
                      <button
                        type="button"
                        onClick={() => onTuneChannel(ch.id)}
                        className={`sticky left-0 z-10 flex w-60 shrink-0 items-center gap-3 border-r border-[#232733] px-4 text-left transition-colors cursor-pointer ${
                          isTuned
                            ? "bg-[#1C1912] text-amber-300"
                            : "bg-[#12141A] text-[#F4F4F5] hover:bg-[#181B23]"
                        }`}
                      >
                        <span className="w-9 shrink-0 font-mono text-sm font-bold text-amber-400 tabular-nums">
                          {String(ch.num).padStart(3, "0")}
                        </span>
                        <div className="min-w-0 flex-1">
                          <div className="truncate text-sm font-semibold">
                            {ch.name}
                          </div>
                          {ch.cat && (
                            <div className="truncate text-[11px] text-[#9CA3AF]">
                              {ch.cat}
                            </div>
                          )}
                        </div>
                      </button>

                      {/* Program Blocks Timeline */}
                      <div
                        className="relative flex-1 bg-[#0E1015]"
                        style={{ width: `${totalWidthPx}px` }}
                      >
                        {nowLineLeftPx !== null && (
                          <div
                            aria-hidden="true"
                            style={{ left: `${nowLineLeftPx}px` }}
                            className="pointer-events-none absolute bottom-0 top-0 z-10 w-px bg-amber-400/50"
                          />
                        )}

                        {blocks.length === 0 ? (
                          <div className="flex h-full items-center px-3 text-xs text-[#6B7280]">
                            Schedule syncing...
                          </div>
                        ) : (
                          blocks.map((block, bIdx) => {
                            const leftPx =
                              ((block.startSec - windowStartSec) / 60) *
                              PIXELS_PER_MINUTE;
                            const widthPx = Math.max(
                              24,
                              ((block.endSec - block.startSec) / 60) *
                                PIXELS_PER_MINUTE
                            );
                            const isBreak = Boolean(block.item.a);

                            return (
                              <button
                                key={`${ch.id}-${block.startSec}-${bIdx}`}
                                type="button"
                                onClick={() => {
                                  if (block.isLive) {
                                    onTuneChannel(ch.id);
                                  } else {
                                    setSelectedUpcoming({
                                      channel: ch,
                                      item: block.item,
                                      startSec: block.startSec,
                                      endSec: block.endSec,
                                    });
                                  }
                                }}
                                style={{
                                  left: `${leftPx}px`,
                                  width: `${widthPx}px`,
                                }}
                                title={`${block.item.t} (${formatClock(
                                  block.startSec * 1000
                                )})`}
                                className={`absolute bottom-1 top-1 flex flex-col justify-center overflow-hidden rounded-md border px-2.5 text-left transition-colors cursor-pointer ${
                                  block.isLive
                                    ? isTuned
                                      ? "border-amber-400/80 bg-amber-500/20 text-amber-100"
                                      : "border-[#363C4D] bg-[#1A1F2B] text-[#F4F4F5] hover:border-amber-400/60"
                                    : isBreak
                                    ? "border-[#1C202B] bg-[#111319] text-[#6B7280]"
                                    : "border-[#232733] bg-[#14171F] text-[#D1D5DB] hover:bg-[#1B1F2A]"
                                }`}
                              >
                                <div className="truncate text-xs font-medium">
                                  {isBreak ? "Commercial Break" : block.item.t}
                                </div>
                                {widthPx > 95 && !isBreak && (
                                  <div className="mt-0.5 truncate font-mono text-[10px] text-[#9CA3AF] tabular-nums">
                                    {formatClock(block.startSec * 1000)} ·{" "}
                                    {formatDuration(block.item.d)}
                                  </div>
                                )}
                              </button>
                            );
                          })
                        )}
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
