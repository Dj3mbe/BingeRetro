import { useMemo } from "react";
import { Heart, Play } from "lucide-react";
import type { Channel, ChannelSchedule } from "../types/tv.ts";
import { getNowNext } from "../utils/scheduleEngine.ts";

interface CategoriesViewProps {
  mode: "categories" | "favorites";
  channels: Channel[];
  schedules: Record<string, ChannelSchedule>;
  globalAnchor: number;
  activeChannelId: string | null;
  favorites: Set<string>;
  onTuneChannel: (channelId: string) => void;
  onToggleFavorite: (channelId: string) => void;
  onBrowseAll: () => void;
  nowMs: number;
}

export function CategoriesView({
  mode,
  channels,
  schedules,
  globalAnchor,
  activeChannelId,
  favorites,
  onTuneChannel,
  onToggleFavorite,
  onBrowseAll,
  nowMs,
}: CategoriesViewProps) {
  const nowSec = nowMs / 1000;

  const grouped = useMemo(() => {
    if (mode === "favorites") {
      const favChannels = channels.filter((ch) => favorites.has(ch.id));
      return favChannels.length
        ? [{ category: "Saved Channels", items: favChannels }]
        : [];
    }

    const map = new Map<string, Channel[]>();
    for (const ch of channels) {
      const key = ch.cat || "General Broadcast";
      const list = map.get(key) || [];
      list.push(ch);
      map.set(key, list);
    }
    return Array.from(map.entries()).map(([category, items]) => ({
      category,
      items,
    }));
  }, [mode, channels, favorites]);

  return (
    <section className="mx-auto max-w-[1440px] px-4 py-6 sm:px-6">
      <div className="flex flex-col gap-3 border-b border-[#232733] pb-5 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold text-[#F4F4F5] sm:text-3xl">
            {mode === "favorites" ? "Favorite Channels" : "Browse by Category"}
          </h1>
          <p className="mt-1 text-sm text-[#9CA3AF]">
            {mode === "favorites"
              ? "Your saved cable channels · Stored locally in your browser"
              : `${channels.length} verified playable 24/7 channels organized by genre`}
          </p>
        </div>
      </div>

      {grouped.length === 0 ? (
        <div className="mt-10 flex flex-col items-center justify-center rounded-xl border border-[#232733] bg-[#12141A] px-6 py-16 text-center">
          <Heart className="h-8 w-8 text-[#6B7280]" aria-hidden="true" />
          <h2 className="mt-4 font-display text-lg font-bold text-[#F4F4F5]">
            No favorite channels saved yet
          </h2>
          <p className="mt-1 max-w-md text-sm text-[#9CA3AF]">
            Click the heart icon on any channel in Watch Live or Categories to build your quick-access cable lineup.
          </p>
          <button
            type="button"
            onClick={onBrowseAll}
            className="mt-5 rounded-lg bg-amber-500 px-4 py-2 text-sm font-semibold text-[#0A0B0E] hover:bg-amber-400 cursor-pointer"
          >
            Browse All Categories
          </button>
        </div>
      ) : (
        <div className="mt-6 space-y-10">
          {grouped.map((group) => (
            <div key={group.category}>
              <div className="mb-3 flex items-baseline justify-between border-b border-[#232733] pb-2">
                <h2 className="font-display text-lg font-bold text-[#F4F4F5]">
                  {group.category}
                </h2>
                <span className="font-mono text-xs text-[#9CA3AF] tabular-nums">
                  {group.items.length}{" "}
                  {group.items.length === 1 ? "channel" : "channels"}
                </span>
              </div>

              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
                {group.items.map((ch) => {
                  const isTuned = ch.id === activeChannelId;
                  const isFav = favorites.has(ch.id);
                  const nowInfo = getNowNext(ch, schedules, globalAnchor, nowSec);

                  return (
                    <div
                      key={ch.id}
                      className={`flex flex-col justify-between rounded-xl border p-4 transition-colors ${
                        isTuned
                          ? "border-amber-500/70 bg-amber-500/10"
                          : "border-[#232733] bg-[#12141A] hover:border-[#343A4A]"
                      }`}
                    >
                      <div>
                        <div className="flex items-start justify-between gap-2">
                          <div className="min-w-0">
                            <div className="flex items-center gap-2 text-xs text-[#9CA3AF]">
                              <span className="font-mono font-bold text-amber-400 tabular-nums">
                                Ch {ch.num}
                              </span>
                              {ch.cat && (
                                <>
                                  <span aria-hidden="true">·</span>
                                  <span className="truncate">{ch.cat}</span>
                                </>
                              )}
                            </div>
                            <h3 className="mt-1 truncate font-display text-base font-bold text-[#F4F4F5]">
                              {ch.name}
                            </h3>
                          </div>

                          <button
                            type="button"
                            onClick={() => onToggleFavorite(ch.id)}
                            aria-label={
                              isFav
                                ? `Remove ${ch.name} from favorites`
                                : `Save ${ch.name} to favorites`
                            }
                            className="rounded-md p-1.5 text-[#9CA3AF] hover:bg-[#1E222D] hover:text-amber-400 cursor-pointer"
                          >
                            <Heart
                              className={`h-4 w-4 ${
                                isFav ? "fill-amber-400 text-amber-400" : ""
                              }`}
                              aria-hidden="true"
                            />
                          </button>
                        </div>

                        <p className="mt-2 truncate text-sm font-medium text-[#E5E7EB]">
                          {nowInfo.currentTitle}
                        </p>
                        {ch.blurb && (
                          <p className="mt-1 text-xs text-[#9CA3AF] line-clamp-2">
                            {ch.blurb}
                          </p>
                        )}
                      </div>

                      <div className="mt-4">
                        {nowInfo.durationSec > 0 && (
                          <div className="mb-3 h-1 w-full overflow-hidden rounded-full bg-[#232733]">
                            <div
                              className="h-full bg-amber-400"
                              style={{ width: `${nowInfo.progressPct}%` }}
                            />
                          </div>
                        )}
                        <button
                          type="button"
                          onClick={() => onTuneChannel(ch.id)}
                          className={`inline-flex w-full items-center justify-center gap-1.5 rounded-lg px-3 py-2 text-xs font-semibold transition-colors cursor-pointer ${
                            isTuned
                              ? "bg-amber-500 text-[#0A0B0E]"
                              : "border border-[#2A2F3D] bg-[#181B23] text-[#F4F4F5] hover:bg-[#232733]"
                          }`}
                        >
                          <Play className="h-3.5 w-3.5 fill-current" aria-hidden="true" />
                          <span>{isTuned ? "Currently Playing" : "Watch Live"}</span>
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      )}
    </section>
  );
}
